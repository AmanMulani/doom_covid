import 'package:flutter/material.dart';

class DrawerSidePane extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        children: <Widget>[
          UserAccountsDrawerHeader(
            accountName: Text('Aman Mulani'),
            accountEmail: Text('amanmulani369@gmail,.com'),
            currentAccountPicture: GestureDetector(
              child: CircleAvatar(
                backgroundColor: Colors.white,
                child: Icon(Icons.person, color: Colors.grey, size: 54.0,),
              ),
            ),
            decoration: BoxDecoration(
              color: Colors.pink,
            ),
          ),
          DrawerSubOptions(title: 'Home', icon: Icons.home,),
          DrawerSubOptions(title: 'My Account', icon: Icons.person,),
          DrawerSubOptions(title: 'My Orders', icon: Icons.shopping_basket,),
          DrawerSubOptions(title: 'Categories', icon: Icons.category,),
          DrawerSubOptions(title: 'Favorites', icon: Icons.favorite,),
          Divider(),
          DrawerSubOptions(title: 'Settings', icon: Icons.settings,),
          DrawerSubOptions(title: 'About', icon: Icons.help,),
        ],
      ),
    );
  }
}

class DrawerSubOptions extends StatelessWidget {

  final String title;
  final IconData icon;
  DrawerSubOptions({this.title, this.icon});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {},
      child: ListTile(
        title: Text(title),
        leading: Icon(icon, color: Colors.redAccent,),
      ),
    );
  }
}

